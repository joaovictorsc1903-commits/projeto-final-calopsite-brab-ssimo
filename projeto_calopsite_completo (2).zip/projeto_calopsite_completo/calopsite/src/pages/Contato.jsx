export default function Contato() {
  return (
    <div>
      <h1>Contato</h1>
    </div>
  );
}