export default function Login() {
  return (
    <div className="max-w-md mx-auto mt-12 p-6 border rounded-lg shadow">
      <h1 className="text-2xl font-bold mb-6 text-center">
        Entrar / Cadastrar
      </h1>

      <form className="flex flex-col gap-4">
        <input
          type="email"
          placeholder="E-mail"
          className="border p-2 rounded"
        />

        <input
          type="password"
          placeholder="Senha"
          className="border p-2 rounded"
        />

        <button
          type="submit"
          className="bg-orange-500 text-white p-2 rounded hover:bg-orange-600"
        >
          Entrar
        </button>
      </form>
    </div>
  );
}  