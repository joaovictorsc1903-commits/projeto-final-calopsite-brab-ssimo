// Mapeia IDs dos produtos de "aves" para fotos/vídeos locais
// Usado no listing de aves (racao, brinquedos e casa)

const AVES_MEDIA = {
  // ===== Aves - ração (pasta /produtos/racao) =====
  29: { image: './produtos/racao/Mistura De Sementes Selecionas Para Calopsitas De 10kgs.webp' },
  30: { image: './produtos/racao/Ração Extrusada para Papagaios 1kg.webp' },
  31: { image: './produtos/racao/Ração Mistura Premium Para Calopsita 10kg.webp' },
  32: { image: './produtos/racao/Ração Para Pássaro Calopsita E Agapornis - 5kg.webp' },
  33: { image: './produtos/racao/Kit 3 Caixas Ração 700gr Suprema Calopsita Reino Das Aves.webp' },
  34: { image: './produtos/racao/Kit 3 Caixas Ração 700gr Suprema Calopsita Reino Das Aves.webp' },
  35: { image: './produtos/racao/Mistura De Sementes Selecionas Para Calopsitas De 10kgs.webp' },
  36: { image: './produtos/racao/Ração Para Pássaro Calopsita E Agapornis - 5kg.webp' },

  // ===== Aves - brinquedos (pasta /produtos/brinquedos) =====
  370: { image: './produtos/brinquedos/brinquedo.3.webp' },
  371: { image: './produtos/brinquedos/brinquedo.teto1.webp' },
  372: { image: './produtos/brinquedos/brinquedo.teto2.webp' },
  373: { image: './produtos/brinquedos/brinquedo.parede1.webp' },
  374: { image: './produtos/brinquedos/brinquedo.parede2.webp' },
  375: { image: './produtos/brinquedos/brinquedo.12.webp' },
  376: { image: './produtos/brinquedos/brinquedo.15.webp' },
  
  // ===== Aves - casa (pasta /produtos/casa) =====
  1044: { image: './produtos/casa/casa.1.webp' },
  1045: { image: './produtos/casa/casa.2.webp' },
  1046: { image: './produtos/casa/casa.3.webp' },
  1047: { image: './produtos/casa/casa.4.webp' },
  1048: { image: './produtos/casa/casa.5.webp' },
};

function getAvesMediaForProduct(p) {
  if (!p || p.cat !== 'aves') return null;
  return AVES_MEDIA[p.id] || null;
}

