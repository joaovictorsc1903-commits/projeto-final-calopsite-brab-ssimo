const path = require('path');
const express = require('express');

const { initDb, health } = require('./db');

const app = express();
const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;

// Pasta raiz do site (onde ficam index.html, style.css, script.js, components, etc.)
const publicDir = __dirname;

app.disable('x-powered-by');

app.use(express.json({ limit: '1mb' }));

// Serve arquivos estáticos
app.use(express.static(publicDir, {
  extensions: ['html'],
  etag: true
}));

// ===== API =====
app.get('/api/health', async (req, res) => {
  try {
    const ok = await health();
    res.json({ ok });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e?.message || e) });
  }
});

// ===== SPA fallback =====
app.get('/', (req, res) => {
  res.sendFile(path.join(publicDir, 'index.html'));
});

app.get('*', (req, res) => {
  res.sendFile(path.join(publicDir, 'index.html'));
});

initDb({ runMigrations: true })
  .catch((e) => {
    console.error('[calopsite] Erro ao inicializar banco:', e);
  })
  .finally(() => {
    app.listen(PORT, () => {
      console.log(`[calopsite] Rodando em http://localhost:${PORT}`);
    });
  });


