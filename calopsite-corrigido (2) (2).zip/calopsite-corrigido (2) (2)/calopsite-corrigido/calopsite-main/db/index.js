const path = require('path');
const fs = require('fs');
const { Pool } = require('pg');

const DATABASE_URL = process.env.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/calopsite';

const pool = new Pool({ connectionString: DATABASE_URL });

async function initDb({ runMigrations = false } = {}) {
  // Sempre garante que consegue conectar
  await pool.query('SELECT 1');

  if (!runMigrations) return { ran: false };

  const sqlPath = path.join(__dirname, 'init.sql');
  const sql = fs.readFileSync(sqlPath, 'utf8');

  // init.sql já contém IF NOT EXISTS nas tabelas, então é seguro de rodar.
  await pool.query(sql);

  return { ran: true };
}

async function health() {
  const r = await pool.query('SELECT 1 AS ok');
  return r.rows?.[0]?.ok === 1;
}

module.exports = {
  pool,
  initDb,
  health,
};

