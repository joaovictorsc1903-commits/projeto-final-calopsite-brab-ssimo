-- Calopsite - schema inicial (PostgreSQL)
-- Rodar este arquivo uma vez para criar tabelas.

CREATE TABLE IF NOT EXISTS users (
  id              SERIAL PRIMARY KEY,
  email           TEXT NOT NULL UNIQUE,
  password_hash  TEXT NOT NULL,
  name            TEXT NOT NULL,
  cpf             TEXT,
  phone           TEXT,
  person_type     TEXT CHECK (person_type IN ('pf','pj') OR person_type IS NULL),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS profiles (
  user_id         INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  avatar_data_url TEXT,
  cep             TEXT,
  rua             TEXT,
  numero         TEXT,
  complemento    TEXT,
  bairro          TEXT,
  cidade          TEXT,
  estado          TEXT,
  applied_coupons JSONB NOT NULL DEFAULT '[]'::jsonb,
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS products (
  id              INTEGER PRIMARY KEY,
  name            TEXT NOT NULL,
  price_cents    INTEGER NOT NULL,
  cat             TEXT,
  sub             TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id              SERIAL PRIMARY KEY,
  user_id         INTEGER REFERENCES users(id) ON DELETE SET NULL,
  status          TEXT NOT NULL DEFAULT 'pending',
  total_cents     INTEGER NOT NULL,
  cep             TEXT,
  rua             TEXT,
  numero         TEXT,
  complemento    TEXT,
  bairro          TEXT,
  cidade          TEXT,
  estado          TEXT,
  payment_method  TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
  id              SERIAL PRIMARY KEY,
  order_id        INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id      INTEGER,
  product_name    TEXT NOT NULL,
  unit_price_cents INTEGER NOT NULL,
  qty             INTEGER NOT NULL,
  frequency       TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at);

