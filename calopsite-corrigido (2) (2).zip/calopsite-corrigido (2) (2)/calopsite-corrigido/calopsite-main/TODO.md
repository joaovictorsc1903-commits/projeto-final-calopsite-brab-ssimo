# TODO - Brinquedos (cards completos)

- [x] Atualizar `js/products-images.js` para mapear imagens dos IDs adicionais de **aves** (brinquedos) a partir dos arquivos em `produtos/brinquedos/`.
- [x] Atualizar `script.js` para adicionar no `products.aves.brinquedos` (cards) mais itens além do id 370, usando nomes genéricos e preços > 30.
- [ ] Validar que o listing de **aves -> brinquedos** renderiza os novos cards e que as imagens carregam (fallback ok se faltar mapeamento).


