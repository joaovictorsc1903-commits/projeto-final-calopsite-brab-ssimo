// Mapeia IDs dos produtos de "aves" para fotos/vídeos locais
// Usado no listing de aves (racao e brinquedos)

const AVES_MEDIA = {
  // ===== Aves - ração (pasta /produtos/racao) =====
  29: { image: './produtos/racao/Mistura De Sementes Selecionas Para Calopsitas De 10kgs.webp' },
  30: { image: './produtos/racao/Ração Extrusada para Papagaios 1kg.webp' },
  31: { image: './produtos/racao/Ração Mistura Premium Para Calopsita 10kg.webp' },
  32: { image: './produtos/racao/Ração Para Pássaro Calopsita E Agapornis - 5kg.webp' },
  33: { image: './produtos/racao/Kit 3 Caixas Ração 700gr Suprema Calopsita Reino Das Aves.webp' },
  34: { image: './produtos/racao/Kit 3 Caixas Ração 700gr Suprema Calopsita Reino Das Aves.webp' },
  35: { image: './produtos/racao/Mistura De Sementes Selecionas Para Calopsitas De 10kgs.webp' },
  36: { image: './produtos/racao/Ração Para Pássaro Calopsita E Agapornis - 5kg.webp' },

  // ===== Aves - brinquedos (pasta /produtos/brinquedos) =====
  // No seu products do script.js, o brinquedo de aves está no listing como id 370.
  // Como o listing só mostra 1 imagem por card, escolhi a primeira opção válida.
  370: {
    image: './produtos/brinquedos/brinquedo.3.webp',
    image: './produtos/brinquedos/brinquedo.12.webp',
  },
};

function getAvesMediaForProduct(p) {
  if (!p || p.cat !== 'aves') return null;
  return AVES_MEDIA[p.id] || null;
}

