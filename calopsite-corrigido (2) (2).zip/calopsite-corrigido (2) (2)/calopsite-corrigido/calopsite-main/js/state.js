// ===== STATE =====
const state = {
  cart: [],
  currentPage: 'home',
  currentCategory: null,
  currentSubcategory: null,
  carouselIndex: 0,
  carouselTimer: null,
  loggedUser: null,
};

