// Exemplo de validação/fluxo de pagamento com cartão (apenas front-end)
// Não integra com PSP. Serve para demonstração no checkout.

(function () {
  function onlyDigits(s) {
    return String(s || '').replace(/\D+/g, '');
  }

  function luhnCheck(cardNumber) {
    const digits = onlyDigits(cardNumber);
    if (!digits || digits.length < 12) return false;

    let sum = 0;
    let shouldDouble = false;

    for (let i = digits.length - 1; i >= 0; i--) {
      let digit = parseInt(digits[i], 10);
      if (shouldDouble) {
        digit = digit * 2;
        if (digit > 9) digit -= 9;
      }
      sum += digit;
      shouldDouble = !shouldDouble;
    }

    return sum % 10 === 0;
  }

  function normalizeCardNumberForDisplay(s) {
    const d = onlyDigits(s);
    return d;
  }

  function parseExpiry(mmYY) {
    // aceita MM/AA ou MMYY
    const raw = String(mmYY || '').trim();
    const digits = onlyDigits(raw);

    if (digits.length === 4) {
      const mm = parseInt(digits.slice(0, 2), 10);
      const aa = parseInt(digits.slice(2, 4), 10);
      return { mm, aa };
    }

    const m = raw.match(/^(\d{2})\s*\/\s*(\d{2})$/);
    if (m) {
      const mm = parseInt(m[1], 10);
      const aa = parseInt(m[2], 10);
      return { mm, aa };
    }

    return null;
  }

  function isExpiryValid(mmYY) {
    const parsed = parseExpiry(mmYY);
    if (!parsed) return false;
    const { mm, aa } = parsed;

    if (mm < 1 || mm > 12) return false;

    const now = new Date();
    const fullYear = 2000 + aa;

    // Expira no fim do mês
    const expiryDate = new Date(fullYear, mm, 0, 23, 59, 59, 999);

    return expiryDate >= now;
  }

  function validateCreditCard({ cardNumber, cardHolder, expiry, cvv }) {
    const errors = [];

    const digits = normalizeCardNumberForDisplay(cardNumber);

    if (!digits || digits.length < 12) errors.push('Número do cartão inválido.');
    else if (!luhnCheck(digits)) errors.push('Número do cartão não passou na validação.');

    const holder = String(cardHolder || '').trim();
    if (!holder || holder.length < 3) errors.push('Nome no cartão é obrigatório.');

    if (!isExpiryValid(expiry)) errors.push('Vencimento inválido ou cartão vencido.');

    const cvvDigits = onlyDigits(cvv);
    if (!cvvDigits || (cvvDigits.length !== 3 && cvvDigits.length !== 4)) {
      errors.push('CVV inválido.');
    }

    return {
      ok: errors.length === 0,
      errors,
    };
  }

  // global
  window.validateCreditCard = validateCreditCard;
})();

