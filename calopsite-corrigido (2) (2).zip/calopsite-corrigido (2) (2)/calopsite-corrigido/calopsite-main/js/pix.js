// ===== PIX QR helper (exemplo) =====
// Não integra com PSP/banco. Serve apenas para demonstração no checkout.

(function () {
  // Carrega a lib QR (qrcode-generator via CDN) de forma dinâmica, para não quebrar caso offline.
  function loadQrLib() {
    return new Promise((resolve) => {
      if (window.QRCode || window.qrcode) return resolve(true);

      const existing = document.querySelector('script[data-qr-lib="qrcode-js"]');
      if (existing) {
        existing.addEventListener('load', () => resolve(true));
        return;
      }

      const s = document.createElement('script');
      s.src = 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';
      s.async = true;
      s.dataset.qrLib = 'qrcode-js';
      s.onload = () => resolve(true);
      s.onerror = () => resolve(false);
      document.head.appendChild(s);
    });
  }

  function centsToBRLAmountString(value) {
    // value em R$
    const fixed = (Number(value) || 0).toFixed(2);
    // Pix payload exige ponto como decimal
    return fixed;
  }

  function sanitizePixString(v) {
    // Mantém caracteres permitidos no payload
    return String(v || '').replace(/\s+/g, '').slice(0, 200);
  }

  // Implementa payload Pix EMV (simplificado) para exemplo.
  // Para produção, use bibliotecas oficiais/validadas.
  function buildPixPayload({
    txid = 'CP-'+Date.now(),
    amount,
    merchantName = 'Calopsite',
    merchantCity = 'Curitiba',
    receiverKey = 'chave-exemplo@calopsite.com',
  }) {
    // Tamanhos variáveis (TLV) no formato do Pix
    function crc16(buf) {
      // CRC16-CCITT (0x1021) - implementação comum para Pix.
      let crc = 0xFFFF;
      for (let i = 0; i < buf.length; i++) {
        crc ^= (buf[i] & 0xFF) << 8;
        for (let j = 0; j < 8; j++) {
          crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) : (crc << 1);
          crc &= 0xFFFF;
        }
      }
      return crc;
    }

    function toTLV(id, value) {
      const v = String(value || '');
      return id + String(v.length).padStart(2, '0') + v;
    }

    function buildEMV({
      receiverKey,
      merchantName,
      merchantCity,
      txid,
      amount,
    }) {
      // Payload Format Indicator: 00
      const payload = {
        0: '01', // payload format indicator
      };

      const gui = buildGui(receiverKey);
      const payloadFields = [];
      payloadFields.push(toTLV('00', '01'));

      // Merchant account information (01 - key)
      payloadFields.push(gui);

      // Merchant category code (52) - comércio (exemplo)
      payloadFields.push(toTLV('52', '0000'));

      // Transaction currency (53) - BRL = 986
      payloadFields.push(toTLV('53', '986'));

      // Transaction amount (54)
      if (amount !== undefined && amount !== null && String(amount).trim() !== '') {
        payloadFields.push(toTLV('54', centsToBRLAmountString(amount)));
      }

      // Country code (58) - BR
      payloadFields.push(toTLV('58', 'BR'));

      // Merchant name (59)
      payloadFields.push(toTLV('59', sanitizePixString(merchantName)));

      // Merchant city (60)
      payloadFields.push(toTLV('60', sanitizePixString(merchantCity)));

      // Additional data field: txid (62)
      const addData = [];
      addData.push(toTLV('05', sanitizePixString(txid)));
      const addDataStr = addData.join('');
      payloadFields.push(toTLV('62', addDataStr));

      // CRC placeholder (63)
      const withoutCRC = payloadFields.join('') + '6304';

      // Compute CRC of withoutCRC bytes (ASCII)
      const bytes = [];
      for (let i = 0; i < withoutCRC.length; i++) bytes.push(withoutCRC.charCodeAt(i));
      const crc = crc16(bytes);
      const crcStr = String(crc).padStart(4, '0');

      return payloadFields.join('') + '6304' + crcStr;
    }

    function buildGui(receiverKey) {
      // Merchant account information template: 01 + 02(key)
      // 01: receive key type + 02: key itself (simplificação)
      // Em exemplo, usar ID do tipo de chave como "chave".
      const key = sanitizePixString(receiverKey);

      // '00' tipo de conta (00), '01' receiver key - abordagem simplificada
      // Estrutura comum: 01 (chave pix): dentro 01-02
      const nested = [];
      nested.push(toTLV('00', 'BR.GOV.BCB.PIX'));
      nested.push(toTLV('01', key));
      const nestedStr = nested.join('');

      // ID 01 no TLV da conta
      return toTLV('26', nestedStr);
    }

    return buildEMV({ receiverKey, merchantName, merchantCity, txid, amount });
  }

  function formatPixCopyPaste(payload) {
    return payload;
  }

  async function renderPixQR({ container, amount }) {
    if (!container) return false;

    const payload = buildPixPayload({
      amount,
      txid: 'CALOP-'+Date.now(),
      merchantName: 'Calopsite',
      merchantCity: 'Curitiba',
      receiverKey: 'chave-exemplo@calopsite.com',
    });

    container.innerHTML = `
      <div class="pix-qr-wrap">
        <div class="pix-qr-title">QR Code Pix</div>
        <div class="pix-qr-kana" aria-hidden="true" style="display:flex;align-items:center;justify-content:center;margin:8px 0 10px;">
          <div style="width:64px;height:64px;border-radius:12px;background:rgba(244,123,32,0.10);display:flex;align-items:center;justify-content:center;font-weight:900;color:var(--orange);">PIX</div>
        </div>
        <div id="pix-qr-target" class="pix-qr-target"></div>
        <div class="pix-amount-row">
          <span>Valor</span>
          <strong>R$ ${(Number(amount) || 0).toFixed(2).replace('.', ',')}</strong>
        </div>
        <div class="pix-copy">
          <label>Copia e cola</label>
          <textarea readonly rows="3">${payload}</textarea>
          <button type="button" class="btn-pix-copy" onclick="window.__pixCopyFromTextarea(this)">Copiar</button>
        </div>
      </div>
    `;

    // Copiar
    window.__pixCopyFromTextarea = function (btn) {
      const wrap = btn.closest('.pix-copy');
      const ta = wrap && wrap.querySelector('textarea');
      if (!ta) return;
      ta.select();
      try { document.execCommand('copy'); } catch {}
      btn.textContent = 'Copiado!';
      setTimeout(() => (btn.textContent = 'Copiar'), 1500);
    };

    const libLoaded = await loadQrLib();
    const target = container.querySelector('#pix-qr-target');
    if (!target) return false;

    if (!libLoaded || !window.QRCode) {
      // fallback: sem QR
      target.innerHTML = `<div style="color:var(--text-mid);font-size:13px;font-weight:700">QR não pôde ser carregado (lib indisponível). Use o “copia e cola”.</div>`;
      return false;
    }

    // qrcodejs: new QRCode(domElement, { text, width, height })
    target.innerHTML = '';
    // eslint-disable-next-line no-undef
    new window.QRCode(target, {
      text: formatPixCopyPaste(payload),
      width: 220,
      height: 220,
      correctLevel: window.QRCode.CorrectLevel.M,
    });

    return true;
  }

  window.renderPixQR = renderPixQR;
})();

