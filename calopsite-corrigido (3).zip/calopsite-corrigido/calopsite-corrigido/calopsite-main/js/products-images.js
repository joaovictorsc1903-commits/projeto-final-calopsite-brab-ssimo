/*
  products-images.js
  Responsável por mapear IDs dos produtos (conforme products no script.js)
  para fotos locais dentro da pasta /produtos.

  Para esta entrega, o objetivo é: garantir que o listing
  use <img> com tamanho fixo e alinhamento consistente.

  IMPORTANTE:
  - Se algum ID não tiver imagens mapeadas, o código cai para o fallback (ícone atual).
*/

const PRODUCT_IMAGES = {
  // ===== cachorro - racao =====
  1:  { images: ["./produtos/brinquedos/brinquedo.0.webp"] },
  2:  { images: ["./produtos/casa/casa.1.webp"] },
  5:  { images: ["./produtos/casa/casa.2.webp"] },
  6:  { images: ["./produtos/casa/casa.3.webp"] },
  7:  { images: ["./produtos/casa/casa.4.webp"] },
  8:  { images: ["./produtos/casa/casa.5.webp"] },

  // ===== cachorro - petiscos =====
  9:  { images: ["./produtos/brinquedos/brinquedo.1.webp"] },
  10: { images: ["./produtos/brinquedos/brinquedo.2.webp"] },

  // ===== cachorro - brinquedos =====
  11: { images: ["./produtos/brinquedos/brinquedo.3.webp"] },
  12: { images: ["./produtos/brinquedos/brinquedo.4.webp"] },
  13: { images: ["./produtos/brinquedos/brinquedo.5.webp"] },
  14: { images: ["./produtos/brinquedos/brinquedo.6.webp"] },
  15: { images: ["./produtos/brinquedos/brinquedo.7.webp"] },
  16: { images: ["./produtos/brinquedos/brinquedo.8.webp"] },
  17: { images: ["./produtos/brinquedos/brinquedo.9.webp"] },
  18: { images: ["./produtos/brinquedos/brinquedo.10.webp"] },

  // ===== cachorro - coleiras =====
  19: { images: ["./produtos/brinquedo_parede/brinquedo.parede1.webp"] },
  20: { images: ["./produtos/brinquedo_teto/brinquedo.teto1.webp"] },

  // ===== cachorro - limpeza =====
  21: { images: ["./produtos/brinquedos/brinquedo.11.webp"] },
  22: { images: ["./produtos/brinquedos/brinquedo.12.webp"] },

  // ===== cachorro - camas =====
  23: { images: ["./produtos/casa/casa.1.webp"] },
  24: { images: ["./produtos/casa/casa.2.webp"] },

  // ===== gato - racao =====
  3:  { images: ["./produtos/casa/casa.3.webp"] },
  25: { images: ["./produtos/casa/casa.4.webp"] },
  26: { images: ["./produtos/casa/casa.5.webp"] },

  // ===== gato - brinquedos =====
  27: { images: ["./produtos/brinquedo_teto/brinquedo.teto2.webp"] },
  28: { images: ["./produtos/brinquedo_parede/brinquedo.parede2.webp"] },

  // ===== aves - racao =====
  29: { images: ["./produtos/brinquedo_parede/brinquedo.parede3.webp"] },
  30: { images: ["./produtos/brinquedo_teto/brinquedo.teto3.webp"] },
  31: { images: ["./produtos/brinquedo_parede/brinquedo.parede4.webp"] },
  32: { images: ["./produtos/brinquedo_teto/brinquedo.teto4.webp"] },
  33: { images: ["./produtos/brinquedo_parede/brinquedo.parede5.webp"] },
  34: { images: ["./produtos/brinquedo_teto/brinquedo.teto5.webp"] },
  35: { images: ["./produtos/brinquedo_parede/brinquedo.parede6.webp"] },
  36: { images: ["./produtos/brinquedo_teto/brinquedo.teto6.webp"] },

  // ===== aves - brinquedos =====
  370: { images: ["./produtos/brinquedos/brinquedo.13.webp"] },
};

function getProductImagesForId(productId) {
  const entry = PRODUCT_IMAGES[productId];
  if (!entry || !Array.isArray(entry.images) || entry.images.length === 0) return null;
  return entry.images;
}

function getProductPrimaryImageUrl(p) {
  if (!p) return null;
  const imgs = getProductImagesForId(p.id);
  return imgs ? imgs[0] : null;
}

function getProductSecondaryImageUrl(p) {
  if (!p) return null;
  const imgs = getProductImagesForId(p.id);
  if (!imgs) return null;
  return imgs.length > 1 ? imgs[1] : imgs[0];
}

