// Mapeia IDs dos produtos de "aves" para fotos/vídeos locais na pasta /produtos_aves
// Ajuste/complete conforme os arquivos que você tiver para cada produto.

const AVES_MEDIA = {
  // id 29: Calopsita 500g
  29: {
    image: './produtos_aves/826976-MLA73546584921_122023-O.jpg',
  },

  // id 30: Papagaios 1kg
  30: {
    image: './produtos_aves/D_NQ_609182-MLA110946015266_052026-OO.webp',
  },

  // id 31: Brinquedo balanço com espelho
  31: {
    image: './produtos_aves/651127-MLB89721964951_082025-P-poleiro-balanco-de-parede-ben-pet-para-aves.webp',
  },
};

function getAvesMediaForProduct(p) {
  if (!p || p.cat !== 'aves') return null;
  return AVES_MEDIA[p.id] || null;
}

