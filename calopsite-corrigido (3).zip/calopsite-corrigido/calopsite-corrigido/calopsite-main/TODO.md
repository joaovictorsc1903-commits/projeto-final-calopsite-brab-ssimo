# TODO - Estrutura do Banco de Dados

- [ ] Atualizar `server/src/db.js` para criar as tabelas:
  - [ ] categories
  - [ ] products
  - [ ] orders
  - [ ] order_items
- [ ] Garantir chaves estrangeiras entre as tabelas (products->categories, orders->users, order_items->orders/products)
- [ ] Criar constraints (NOT NULL, CHECKs para quantidade e valores monetários)
- [ ] Criar índices para performance nas FKs
- [ ] Rodar o servidor para validar que o `initDb()` cria tudo sem erros
