import { useContext, useState } from "react";
import { Link } from "react-router-dom";
import { FaCheck, FaShoppingCart } from "react-icons/fa";
import { CartContext } from "../context/CartContext";
import BotaoFavorito from "./BotaoFavorito";
import EstrelasAvaliacao from "./EstrelasAvaliacao";
import { listarAvaliacoes, calcularMedia } from "../utils/avaliacoes";

export default function ProdutoCard({ produto }) {
  const { id, nome, preco, imagem, descricao } = produto;
  const cart = useContext(CartContext);
  const [adicionado, setAdicionado] = useState(false);

  const avaliacoes = listarAvaliacoes(id);
  const media = calcularMedia(avaliacoes);

  const handleComprar = (e) => {
    e.preventDefault();
    cart?.adicionarItem(produto, 1);
    setAdicionado(true);
    setTimeout(() => setAdicionado(false), 1500);
  };

  return (
    <Link
      to={`/produto/${id}`}
      className="border rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow bg-white flex flex-col relative"
    >
      <BotaoFavorito
        produtoId={id}
        tamanho={15}
        className="absolute top-2 right-2 z-10 w-8 h-8 bg-white/90 shadow-sm"
      />

      <div className="h-48 bg-gray-100 overflow-hidden">
        <img
          src={imagem}
          alt={nome}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
          onError={(e) => {
            e.target.src = "https://placehold.co/300x200?text=Produto";
          }}
        />
      </div>

      <div className="p-4 flex flex-col flex-1">
        <h3 className="font-semibold text-gray-800 text-sm leading-snug mb-1 line-clamp-2">
          {nome}
        </h3>

        {avaliacoes.length > 0 && (
          <div className="flex items-center gap-1.5 mb-1.5">
            <EstrelasAvaliacao nota={media} tamanho={11} />
            <span className="text-[11px] text-gray-400">({avaliacoes.length})</span>
          </div>
        )}

        <p className="text-gray-500 text-xs mb-3 line-clamp-2 flex-1">
          {descricao}
        </p>
        <div className="flex items-center justify-between mt-auto gap-2">
          <span className="text-orange-600 font-bold text-lg">
            R$ {preco.toFixed(2).replace(".", ",")}
          </span>
          <button
            onClick={handleComprar}
            type="button"
            className={`flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              adicionado
                ? "bg-green-600 text-white"
                : "bg-orange-500 hover:bg-orange-600 text-white"
            }`}
          >
            {adicionado ? (
              <>
                <FaCheck size={12} /> Adicionado
              </>
            ) : (
              <>
                <FaShoppingCart size={12} /> Comprar
              </>
            )}
          </button>
        </div>
      </div>
    </Link>
  );
}
