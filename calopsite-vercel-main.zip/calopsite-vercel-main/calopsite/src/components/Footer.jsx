import { Link } from "react-router-dom";
import {
  FaFacebookF,
  FaInstagram,
  FaLinkedinIn,
  FaYoutube,
  FaTiktok,
  FaPinterestP,
  FaCcVisa,
  FaCcMastercard,
  FaBarcode,
  FaQrcode,
  FaShieldAlt,
  FaLock,
} from "react-icons/fa";
import logo from "../assets/logo.png";

const COLUNAS = [
  {
    titulo: "Sobre",
    links: [
      { nome: "Quem somos", to: "/" },
      { nome: "Trabalhe com a gente", to: "/" },
      { nome: "Mapa do Site", to: "/" },
    ],
  },
  {
    titulo: "Acesse",
    links: [
      { nome: "Meu Cadastro", to: "/cadastro" },
      { nome: "Meus Pedidos", to: "/meus-pedidos" },
      { nome: "Favoritos", to: "/favoritos" },
      { nome: "Entrar", to: "/login" },
    ],
  },
  {
    titulo: "Categorias",
    links: [
      { nome: "Alimentação", to: "/categoria/alimentacao" },
      { nome: "Habitat", to: "/categoria/habitat" },
      { nome: "Enriquecimento", to: "/categoria/enriquecimento" },
      { nome: "Monte seu Habitat", to: "/monte-seu-habitat" },
    ],
  },
  {
    titulo: "Aprenda",
    links: [
      { nome: "Sobre as aves", to: "/aprenda/aves" },
      { nome: "Meio Ambiente", to: "/aprenda/meio-ambiente" },
    ],
  },
  {
    titulo: "Precisa de ajuda?",
    links: [
      { nome: "Fale com a gente", to: "/" },
      { nome: "Trocas e devoluções", to: "/" },
      { nome: "Como Comprar", to: "/" },
    ],
  },
  {
    titulo: "Políticas",
    links: [
      { nome: "Entrega", to: "/" },
      { nome: "Frete grátis", to: "/" },
      { nome: "Privacidade", to: "/" },
    ],
  },
];

const REDES_SOCIAIS = [
  { Icon: FaFacebookF, label: "Facebook", href: "#" },
  { Icon: FaInstagram, label: "Instagram", href: "#" },
  { Icon: FaLinkedinIn, label: "LinkedIn", href: "#" },
  { Icon: FaYoutube, label: "YouTube", href: "#" },
  { Icon: FaTiktok, label: "TikTok", href: "#" },
  { Icon: FaPinterestP, label: "Pinterest", href: "#" },
];

export default function Footer() {
  const ano = new Date().getFullYear();

  return (
    <footer className="bg-[#FFF7E8] border-t border-orange-100 mt-12">
      <div className="max-w-7xl mx-auto px-8 py-12">
        {/* COLUNAS DE LINKS */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-8">
          {COLUNAS.map((coluna) => (
            <div key={coluna.titulo}>
              <h3 className="font-bold text-gray-800 mb-4">{coluna.titulo}</h3>
              <ul className="flex flex-col gap-2.5">
                {coluna.links.map((link) => (
                  <li key={link.nome}>
                    <Link
                      to={link.to}
                      className="text-sm text-gray-600 hover:text-orange-600 transition"
                    >
                      {link.nome}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-orange-100 mt-10 pt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* SELOS / SEGURANÇA */}
          <div>
            <h3 className="font-bold text-gray-800 mb-4">Compra Segura</h3>
            <div className="flex gap-3">
              <div className="flex items-center justify-center w-14 h-10 bg-white border border-gray-200 rounded-md">
                <FaShieldAlt className="text-gray-500" size={18} />
              </div>
              <div className="flex items-center justify-center w-14 h-10 bg-white border border-gray-200 rounded-md">
                <FaLock className="text-gray-500" size={18} />
              </div>
            </div>
          </div>

          {/* FORMAS DE PAGAMENTO */}
          <div>
            <h3 className="font-bold text-gray-800 mb-4">Formas de Pagamento</h3>
            <div className="flex flex-wrap gap-3">
              <div className="flex items-center justify-center w-14 h-10 bg-white border border-gray-200 rounded-md">
                <FaCcVisa className="text-gray-600" size={26} />
              </div>
              <div className="flex items-center justify-center w-14 h-10 bg-white border border-gray-200 rounded-md">
                <FaCcMastercard className="text-gray-600" size={26} />
              </div>
              <div className="flex items-center justify-center w-14 h-10 bg-white border border-gray-200 rounded-md">
                <FaBarcode className="text-gray-600" size={20} />
              </div>
              <div className="flex items-center justify-center w-14 h-10 bg-white border border-gray-200 rounded-md">
                <FaQrcode className="text-gray-600" size={18} />
              </div>
            </div>
          </div>

          {/* REDES SOCIAIS */}
          <div>
            <h3 className="font-bold text-gray-800 mb-4">Redes Sociais</h3>
            <div className="flex flex-wrap gap-3">
              {REDES_SOCIAIS.map(({ Icon, label, href }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="flex items-center justify-center w-10 h-10 bg-white border border-gray-200 rounded-md text-gray-700 hover:bg-orange-500 hover:text-white hover:border-orange-500 transition-colors"
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* MARCA */}
          <div className="flex flex-col items-start sm:items-end">
            <h3 className="font-bold text-gray-800 mb-4 self-start sm:self-end">
              Plataforma
            </h3>
            <img src={logo} alt="Logo Calopsite" className="w-28 h-auto" />
          </div>
        </div>
      </div>

      <div className="border-t border-orange-100 bg-[#FFEDCB]">
        <div className="max-w-7xl mx-auto px-8 py-4 flex flex-col sm:flex-row justify-between items-center gap-2 text-xs text-gray-500">
          <span>© {ano} Calopsite. Todos os direitos reservados.</span>
          <span>CNPJ 00.000.000/0001-00</span>
        </div>
      </div>
    </footer>
  );
}
