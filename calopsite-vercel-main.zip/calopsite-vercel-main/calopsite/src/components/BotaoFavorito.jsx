import { useContext } from "react";
import { FaHeart, FaRegHeart } from "react-icons/fa";
import { FavoritosContext } from "../context/FavoritosContext";

export default function BotaoFavorito({ produtoId, tamanho = 16, className = "" }) {
  const favoritos = useContext(FavoritosContext);
  const ativo = favoritos?.isFavorito(produtoId);

  return (
    <button
      type="button"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        favoritos?.alternarFavorito(produtoId);
      }}
      aria-label={ativo ? "Remover dos favoritos" : "Adicionar aos favoritos"}
      title={ativo ? "Remover dos favoritos" : "Adicionar aos favoritos"}
      className={`flex items-center justify-center rounded-full transition-colors ${
        ativo ? "text-red-500" : "text-gray-400 hover:text-red-400"
      } ${className}`}
    >
      {ativo ? <FaHeart size={tamanho} /> : <FaRegHeart size={tamanho} />}
    </button>
  );
}
