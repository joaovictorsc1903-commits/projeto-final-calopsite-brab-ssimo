import { FaStar, FaStarHalfAlt, FaRegStar } from "react-icons/fa";

export default function EstrelasAvaliacao({
  nota = 0,
  tamanho = 14,
  interativo = false,
  onChange,
}) {
  const estrelas = [1, 2, 3, 4, 5];

  if (interativo) {
    return (
      <div className="flex gap-1">
        {estrelas.map((valor) => (
          <button
            key={valor}
            type="button"
            onClick={() => onChange?.(valor)}
            className="text-yellow-500 hover:scale-110 transition-transform"
            aria-label={`Dar nota ${valor}`}
          >
            {valor <= nota ? <FaStar size={tamanho + 6} /> : <FaRegStar size={tamanho + 6} />}
          </button>
        ))}
      </div>
    );
  }

  return (
    <div className="flex gap-0.5 text-yellow-500">
      {estrelas.map((valor) => {
        if (valor <= Math.floor(nota)) {
          return <FaStar key={valor} size={tamanho} />;
        }
        if (valor - nota < 1 && valor - nota > 0) {
          return <FaStarHalfAlt key={valor} size={tamanho} />;
        }
        return <FaRegStar key={valor} size={tamanho} className="text-gray-300" />;
      })}
    </div>
  );
}
