// Cupons de desconto disponíveis na loja (dados de demonstração)

const cupons = [
  {
    codigo: "BEMVINDO10",
    tipo: "percentual",
    valor: 10,
    descricao: "10% de desconto para o seu primeiro pedido",
    minimo: 0,
  },
  {
    codigo: "CALOPSITA20",
    tipo: "percentual",
    valor: 20,
    descricao: "20% de desconto em compras acima de R$ 100",
    minimo: 100,
  },
  {
    codigo: "FRETE15",
    tipo: "fixo",
    valor: 15,
    descricao: "R$ 15 de desconto direto no pedido",
    minimo: 50,
  },
];

export function buscarCupom(codigo) {
  const normalizado = String(codigo || "").trim().toUpperCase();
  return cupons.find((c) => c.codigo === normalizado) || null;
}

export function calcularDesconto(cupom, subtotal) {
  if (!cupom) return 0;
  if (subtotal < cupom.minimo) return 0;

  if (cupom.tipo === "percentual") {
    return Math.round(subtotal * (cupom.valor / 100) * 100) / 100;
  }
  return Math.min(cupom.valor, subtotal);
}

export default cupons;
