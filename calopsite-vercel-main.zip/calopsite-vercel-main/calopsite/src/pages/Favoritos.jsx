import { useContext } from "react";
import { Link } from "react-router-dom";
import { FaHeart, FaArrowLeft } from "react-icons/fa";
import { FavoritosContext } from "../context/FavoritosContext";
import produtos from "../data/Produtos";
import ProdutoCard from "../components/ProdutoCard";

export default function Favoritos() {
  const favoritosCtx = useContext(FavoritosContext);
  const idsFavoritos = favoritosCtx?.favoritos || [];

  const produtosFavoritos = produtos.filter((p) => idsFavoritos.includes(p.id));

  if (produtosFavoritos.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-16 text-center">
        <FaHeart className="mx-auto text-gray-300 mb-4" size={56} />
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          Você ainda não tem favoritos
        </h1>
        <p className="text-gray-500 mb-8">
          Toque no coração dos produtos que você gosta para guardá-los aqui.
        </p>
        <Link
          to="/produtos"
          className="inline-flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-medium px-6 py-3 rounded-full transition"
        >
          <FaArrowLeft size={14} /> Ver produtos
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <h1 className="text-3xl font-bold text-gray-800 mb-1">Meus Favoritos</h1>
      <p className="text-gray-500 mb-8">
        {produtosFavoritos.length} produto{produtosFavoritos.length !== 1 ? "s" : ""} salvo{produtosFavoritos.length !== 1 ? "s" : ""}
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {produtosFavoritos.map((produto) => (
          <ProdutoCard key={produto.id} produto={produto} />
        ))}
      </div>
    </div>
  );
}
