import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FaCheckCircle, FaBoxOpen, FaHome, FaTruck } from "react-icons/fa";
import { lerUltimoPedido } from "../utils/pedidos";

const LABEL_PAGAMENTO = {
  pix: "Pix",
  cartao: "Cartão de Crédito",
  boleto: "Boleto",
};

export default function PedidoConfirmado() {
  const navigate = useNavigate();
  const [pedido] = useState(() => lerUltimoPedido());

  useEffect(() => {
    if (!pedido) {
      navigate("/", { replace: true });
    }
  }, [pedido, navigate]);

  if (!pedido) return null;

  const formatarPreco = (valor) => `R$ ${valor.toFixed(2).replace(".", ",")}`;
  const dataFormatada = new Date(pedido.data).toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });

  const previsaoEntrega = new Date(pedido.data);
  previsaoEntrega.setDate(previsaoEntrega.getDate() + 7);
  const previsaoFormatada = previsaoEntrega.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "long",
  });

  return (
    <div className="max-w-3xl mx-auto px-6 py-14">
      <div className="text-center mb-10">
        <FaCheckCircle className="mx-auto text-green-500 mb-4" size={72} />
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          Compra realizada com sucesso!
        </h1>
        <p className="text-gray-500">
          Obrigado por comprar na Calopsite. Enviamos os detalhes do pedido para você.
        </p>
      </div>

      <div className="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-6">
        <div className="flex flex-wrap justify-between gap-4 mb-6 pb-6 border-b border-gray-100">
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wide">Número do pedido</p>
            <p className="font-bold text-gray-800 text-lg">{pedido.numero}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wide">Data</p>
            <p className="font-medium text-gray-700">{dataFormatada}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wide">Pagamento</p>
            <p className="font-medium text-gray-700">
              {LABEL_PAGAMENTO[pedido.pagamento] || pedido.pagamento}
              {pedido.pagamento === "cartao" && pedido.parcelas > 1
                ? ` (${pedido.parcelas}x)`
                : ""}
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3 mb-6 pb-6 border-b border-gray-100">
          <FaBoxOpen className="text-orange-500 mt-1" size={20} />
          <div>
            <p className="font-medium text-gray-800">
              Previsão de entrega: {previsaoFormatada}
            </p>
            <p className="text-sm text-gray-500">
              {pedido.endereco?.logradouro}, {pedido.endereco?.numero}
              {pedido.endereco?.complemento ? ` - ${pedido.endereco.complemento}` : ""} ·{" "}
              {pedido.endereco?.bairro}, {pedido.endereco?.localidade}/{pedido.endereco?.uf} ·{" "}
              CEP {pedido.endereco?.cep}
            </p>
          </div>
        </div>

        <div className="flex flex-col gap-3 mb-6">
          {pedido.itens?.map((item) => (
            <div key={item.id} className="flex items-center gap-3">
              <img
                src={item.imagem}
                alt={item.nome}
                className="w-14 h-14 object-cover rounded-lg bg-gray-100 flex-shrink-0"
                onError={(e) => {
                  e.target.src = "https://placehold.co/56x56?text=Produto";
                }}
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-700 truncate">{item.nome}</p>
                <p className="text-xs text-gray-400">Qtd: {item.quantidade}</p>
              </div>
              <span className="text-sm font-semibold text-gray-700 whitespace-nowrap">
                {formatarPreco(item.preco * item.quantidade)}
              </span>
            </div>
          ))}
        </div>

        <div className="border-t border-gray-100 pt-4 flex flex-col gap-2">
          <div className="flex justify-between text-sm text-gray-600">
            <span>Subtotal</span>
            <span>{formatarPreco(pedido.totalPreco)}</span>
          </div>
          <div className="flex justify-between text-sm text-gray-600">
            <span>Frete</span>
            <span className={pedido.frete === 0 ? "text-green-600 font-medium" : ""}>
              {pedido.frete === 0 ? "Grátis" : formatarPreco(pedido.frete)}
            </span>
          </div>
          {pedido.desconto > 0 && (
            <div className="flex justify-between text-sm text-green-600 font-medium">
              <span>Desconto ({pedido.cupom})</span>
              <span>− {formatarPreco(pedido.desconto)}</span>
            </div>
          )}
          <div className="flex justify-between items-baseline pt-2">
            <span className="font-semibold text-gray-800">Total pago</span>
            <span className="text-2xl font-bold text-orange-600">
              {formatarPreco(pedido.total)}
            </span>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row justify-center gap-3">
        <Link
          to={`/pedido/${pedido.numero}/rastreio`}
          className="inline-flex items-center justify-center gap-2 bg-white border border-orange-300 text-orange-600 hover:bg-orange-50 font-medium px-6 py-3 rounded-full transition"
        >
          <FaTruck size={14} /> Acompanhar pedido
        </Link>
        <Link
          to="/"
          className="inline-flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-medium px-6 py-3 rounded-full transition"
        >
          <FaHome size={14} /> Voltar para a loja
        </Link>
      </div>
    </div>
  );
}
