import { useContext, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import {
  FaCreditCard,
  FaBarcode,
  FaQrcode,
  FaMapMarkerAlt,
  FaArrowLeft,
  FaSpinner,
  FaTag,
  FaCheckCircle,
  FaTimes,
} from "react-icons/fa";
import { CartContext } from "../context/CartContext";
import { AuthContext } from "../context/AuthContext";
import { fetchCepData, normalizeCep } from "../utils/cep";
import { buscarCupom, calcularDesconto } from "../data/Cupons";
import { salvarPedido } from "../utils/pedidos";

const PAGAMENTOS = [
  { id: "pix", label: "Pix", icon: FaQrcode, descricao: "Aprovação imediata" },
  { id: "cartao", label: "Cartão de Crédito", icon: FaCreditCard, descricao: "Em até 12x" },
  { id: "boleto", label: "Boleto", icon: FaBarcode, descricao: "Vencimento em 3 dias úteis" },
];

export default function Checkout() {
  const cart = useContext(CartContext);
  const auth = useContext(AuthContext);
  const navigate = useNavigate();

  const itens = cart?.itens || [];
  const totalPreco = cart?.totalPreco || 0;
  const totalItens = cart?.totalItens || 0;

  const [endereco, setEndereco] = useState({
    cep: "",
    logradouro: "",
    numero: "",
    complemento: "",
    bairro: "",
    localidade: "",
    uf: "",
  });
  const [buscandoCep, setBuscandoCep] = useState(false);
  const [erroCep, setErroCep] = useState("");
  const [pagamento, setPagamento] = useState("pix");
  const [parcelas, setParcelas] = useState(1);
  const [cartaoDados, setCartaoDados] = useState({ numero: "", nome: "", validade: "", cvv: "" });
  const [processando, setProcessando] = useState(false);
  const [erroForm, setErroForm] = useState("");

  const [codigoCupom, setCodigoCupom] = useState("");
  const [cupomAplicado, setCupomAplicado] = useState(null);
  const [erroCupom, setErroCupom] = useState("");

  const formatarPreco = (valor) => `R$ ${valor.toFixed(2).replace(".", ",")}`;

  const frete = totalPreco > 0 && totalPreco < 150 ? 19.9 : totalPreco > 0 ? 0 : 0;
  const desconto = calcularDesconto(cupomAplicado, totalPreco);
  const totalComFrete = Math.max(0, totalPreco + frete - desconto);

  const handleAplicarCupom = (e) => {
    e.preventDefault();
    setErroCupom("");
    const cupom = buscarCupom(codigoCupom);

    if (!cupom) {
      setErroCupom("Cupom inválido ou expirado.");
      setCupomAplicado(null);
      return;
    }
    if (totalPreco < cupom.minimo) {
      setErroCupom(`Esse cupom exige compra mínima de ${formatarPreco(cupom.minimo)}.`);
      setCupomAplicado(null);
      return;
    }

    setCupomAplicado(cupom);
  };

  const handleRemoverCupom = () => {
    setCupomAplicado(null);
    setCodigoCupom("");
    setErroCupom("");
  };

  const handleCepBlur = async () => {
    const normalized = normalizeCep(endereco.cep);
    if (!normalized) {
      setErroCep("");
      return;
    }
    setBuscandoCep(true);
    setErroCep("");
    try {
      const data = await fetchCepData(endereco.cep);
      setEndereco((prev) => ({
        ...prev,
        cep: data.cep,
        logradouro: data.logradouro,
        bairro: data.bairro,
        localidade: data.localidade,
        uf: data.uf,
      }));
    } catch (err) {
      setErroCep(err.message || "Não foi possível buscar o CEP");
    } finally {
      setBuscandoCep(false);
    }
  };

  const handleFinalizarCompra = (e) => {
    e.preventDefault();
    setErroForm("");

    if (itens.length === 0) {
      setErroForm("Seu carrinho está vazio.");
      return;
    }
    if (!endereco.cep || !endereco.logradouro || !endereco.numero || !endereco.localidade) {
      setErroForm("Preencha o endereço de entrega completo.");
      return;
    }
    if (pagamento === "cartao") {
      if (!cartaoDados.numero || !cartaoDados.nome || !cartaoDados.validade || !cartaoDados.cvv) {
        setErroForm("Preencha os dados do cartão.");
        return;
      }
    }

    setProcessando(true);

    // Simula processamento do pedido
    setTimeout(() => {
      const numeroPedido = `CLP-${Date.now().toString().slice(-8)}`;
      const pedidoFinalizado = {
        numero: numeroPedido,
        itens,
        totalPreco,
        frete,
        cupom: cupomAplicado?.codigo || null,
        desconto,
        total: totalComFrete,
        endereco,
        pagamento,
        parcelas: pagamento === "cartao" ? parcelas : 1,
        data: new Date().toISOString(),
      };

      salvarPedido(pedidoFinalizado, auth?.user?.email);

      cart?.limparCarrinho();
      setProcessando(false);
      navigate("/pedido-confirmado");
    }, 1400);
  };

  if (itens.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-16 text-center">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          Seu carrinho está vazio
        </h1>
        <p className="text-gray-500 mb-8">
          Adicione produtos ao carrinho antes de finalizar a compra.
        </p>
        <Link
          to="/produtos"
          className="inline-flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-medium px-6 py-3 rounded-full transition"
        >
          <FaArrowLeft size={14} /> Ver produtos
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-6 py-10">
      <Link
        to="/carrinho"
        className="inline-flex items-center gap-2 text-orange-600 hover:text-orange-700 font-medium mb-6 text-sm"
      >
        <FaArrowLeft size={12} /> Voltar ao carrinho
      </Link>

      <h1 className="text-3xl font-bold text-gray-800 mb-8">Finalizar Compra</h1>

      <form onSubmit={handleFinalizarCompra} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 flex flex-col gap-6">
          {/* ENDEREÇO */}
          <section className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
            <h2 className="flex items-center gap-2 text-lg font-bold text-gray-800 mb-4">
              <FaMapMarkerAlt className="text-orange-500" /> Endereço de entrega
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-1">
                <label className="block text-xs font-medium text-gray-600 mb-1">CEP</label>
                <input
                  type="text"
                  value={endereco.cep}
                  onChange={(e) => setEndereco((p) => ({ ...p, cep: e.target.value }))}
                  onBlur={handleCepBlur}
                  placeholder="00000-000"
                  maxLength={9}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-orange-400"
                />
                {buscandoCep && (
                  <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                    <FaSpinner className="animate-spin" size={10} /> Buscando...
                  </p>
                )}
                {erroCep && <p className="text-xs text-red-500 mt-1">{erroCep}</p>}
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-gray-600 mb-1">Logradouro</label>
                <input
                  type="text"
                  value={endereco.logradouro}
                  onChange={(e) => setEndereco((p) => ({ ...p, logradouro: e.target.value }))}
                  placeholder="Rua, avenida..."
                  className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-orange-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Número</label>
                <input
                  type="text"
                  value={endereco.numero}
                  onChange={(e) => setEndereco((p) => ({ ...p, numero: e.target.value }))}
                  placeholder="Nº"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-orange-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Complemento</label>
                <input
                  type="text"
                  value={endereco.complemento}
                  onChange={(e) => setEndereco((p) => ({ ...p, complemento: e.target.value }))}
                  placeholder="Apto, bloco..."
                  className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-orange-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Bairro</label>
                <input
                  type="text"
                  value={endereco.bairro}
                  onChange={(e) => setEndereco((p) => ({ ...p, bairro: e.target.value }))}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-orange-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Cidade</label>
                <input
                  type="text"
                  value={endereco.localidade}
                  onChange={(e) => setEndereco((p) => ({ ...p, localidade: e.target.value }))}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-orange-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">UF</label>
                <input
                  type="text"
                  value={endereco.uf}
                  onChange={(e) => setEndereco((p) => ({ ...p, uf: e.target.value.toUpperCase() }))}
                  maxLength={2}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-orange-400"
                />
              </div>
            </div>
          </section>

          {/* PAGAMENTO */}
          <section className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
            <h2 className="text-lg font-bold text-gray-800 mb-4">Forma de pagamento</h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
              {PAGAMENTOS.map((opcao) => {
                const Icon = opcao.icon;
                const ativo = pagamento === opcao.id;
                return (
                  <button
                    key={opcao.id}
                    type="button"
                    onClick={() => setPagamento(opcao.id)}
                    className={`flex flex-col items-center gap-1.5 border rounded-xl px-3 py-4 transition ${
                      ativo
                        ? "border-orange-500 bg-orange-50 ring-1 ring-orange-400"
                        : "border-gray-200 hover:border-orange-300"
                    }`}
                  >
                    <Icon className={ativo ? "text-orange-600" : "text-gray-500"} size={22} />
                    <span className={`text-sm font-medium ${ativo ? "text-orange-700" : "text-gray-700"}`}>
                      {opcao.label}
                    </span>
                    <span className="text-[11px] text-gray-400">{opcao.descricao}</span>
                  </button>
                );
              })}
            </div>

            {pagamento === "cartao" && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-2">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-gray-600 mb-1">Número do cartão</label>
                  <input
                    type="text"
                    value={cartaoDados.numero}
                    onChange={(e) => setCartaoDados((p) => ({ ...p, numero: e.target.value }))}
                    placeholder="0000 0000 0000 0000"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-orange-400"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-gray-600 mb-1">Nome no cartão</label>
                  <input
                    type="text"
                    value={cartaoDados.nome}
                    onChange={(e) => setCartaoDados((p) => ({ ...p, nome: e.target.value }))}
                    placeholder="Como está no cartão"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-orange-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Validade</label>
                  <input
                    type="text"
                    value={cartaoDados.validade}
                    onChange={(e) => setCartaoDados((p) => ({ ...p, validade: e.target.value }))}
                    placeholder="MM/AA"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-orange-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">CVV</label>
                  <input
                    type="text"
                    value={cartaoDados.cvv}
                    onChange={(e) => setCartaoDados((p) => ({ ...p, cvv: e.target.value }))}
                    placeholder="000"
                    maxLength={4}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-orange-400"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-gray-600 mb-1">Parcelas</label>
                  <select
                    value={parcelas}
                    onChange={(e) => setParcelas(Number(e.target.value))}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-orange-400"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((n) => (
                      <option key={n} value={n}>
                        {n}x de {formatarPreco(totalComFrete / n)} {n === 1 ? "sem juros" : "sem juros"}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {pagamento === "pix" && (
              <p className="text-sm text-gray-500 mt-2">
                Ao finalizar, você receberá o QR Code Pix para pagamento imediato.
              </p>
            )}

            {pagamento === "boleto" && (
              <p className="text-sm text-gray-500 mt-2">
                O boleto será gerado após a confirmação do pedido, com vencimento em 3 dias úteis.
              </p>
            )}
          </section>

          {/* CUPOM DE DESCONTO */}
          <section className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
            <h2 className="flex items-center gap-2 text-lg font-bold text-gray-800 mb-4">
              <FaTag className="text-orange-500" /> Cupom de desconto
            </h2>

            {cupomAplicado ? (
              <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-lg px-4 py-3">
                <div className="flex items-center gap-2">
                  <FaCheckCircle className="text-green-600" />
                  <div>
                    <p className="text-sm font-semibold text-green-800">
                      {cupomAplicado.codigo}
                    </p>
                    <p className="text-xs text-green-600">{cupomAplicado.descricao}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleRemoverCupom}
                  className="text-gray-400 hover:text-red-500 transition p-1"
                  aria-label="Remover cupom"
                >
                  <FaTimes size={14} />
                </button>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={codigoCupom}
                    onChange={(e) => setCodigoCupom(e.target.value.toUpperCase())}
                    placeholder="Digite o código do cupom"
                    className="flex-1 border border-gray-300 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400"
                  />
                  <button
                    type="button"
                    onClick={handleAplicarCupom}
                    disabled={!codigoCupom.trim()}
                    className="bg-gray-800 hover:bg-gray-900 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-medium px-4 py-2.5 rounded-lg transition whitespace-nowrap"
                  >
                    Aplicar
                  </button>
                </div>
                {erroCupom && <p className="text-xs text-red-500">{erroCupom}</p>}
                <p className="text-xs text-gray-400">
                  Experimente: BEMVINDO10, CALOPSITA20 ou FRETE15
                </p>
              </div>
            )}
          </section>

          {erroForm && (
            <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-4 py-3">
              {erroForm}
            </p>
          )}
        </div>

        {/* RESUMO */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm h-fit sticky top-6">
          <h2 className="text-lg font-bold text-gray-800 mb-4">Resumo do pedido</h2>

          <div className="flex flex-col gap-3 mb-4 max-h-[220px] overflow-y-auto pr-1">
            {itens.map((item) => (
              <div key={item.id} className="flex items-center gap-3">
                <img
                  src={item.imagem}
                  alt={item.nome}
                  className="w-12 h-12 object-cover rounded-lg bg-gray-100 flex-shrink-0"
                  onError={(e) => {
                    e.target.src = "https://placehold.co/48x48?text=Produto";
                  }}
                />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-gray-700 truncate">{item.nome}</p>
                  <p className="text-xs text-gray-400">Qtd: {item.quantidade}</p>
                </div>
                <span className="text-sm font-semibold text-gray-700 whitespace-nowrap">
                  {formatarPreco(item.preco * item.quantidade)}
                </span>
              </div>
            ))}
          </div>

          <div className="border-t border-gray-200 pt-4 flex flex-col gap-2">
            <div className="flex justify-between text-sm text-gray-600">
              <span>Subtotal ({totalItens} {totalItens === 1 ? "item" : "itens"})</span>
              <span>{formatarPreco(totalPreco)}</span>
            </div>
            <div className="flex justify-between text-sm text-gray-600">
              <span>Frete</span>
              <span className={frete === 0 ? "text-green-600 font-medium" : ""}>
                {frete === 0 ? "Grátis" : formatarPreco(frete)}
              </span>
            </div>
            {desconto > 0 && (
              <div className="flex justify-between text-sm text-green-600 font-medium">
                <span>Desconto ({cupomAplicado?.codigo})</span>
                <span>− {formatarPreco(desconto)}</span>
              </div>
            )}
            <div className="flex justify-between items-baseline pt-2 border-t border-gray-100 mt-1">
              <span className="font-semibold text-gray-800">Total</span>
              <span className="text-2xl font-bold text-orange-600">
                {formatarPreco(totalComFrete)}
              </span>
            </div>
          </div>

          <button
            type="submit"
            disabled={processando}
            className="w-full bg-orange-500 hover:bg-orange-600 disabled:opacity-60 disabled:cursor-not-allowed text-white font-semibold py-3 rounded-full transition mt-6 flex items-center justify-center gap-2"
          >
            {processando ? (
              <>
                <FaSpinner className="animate-spin" /> Processando...
              </>
            ) : (
              "Confirmar Pedido"
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
