import { useMemo, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import produtos from "../data/Produtos";
import ProdutoCard from "../components/ProdutoCard";
import FiltrosProdutos from "../components/FiltrosProdutos";
import { listarAvaliacoes, calcularMedia } from "../utils/avaliacoes";

const PRECO_MAXIMO_CATALOGO = Math.ceil(
  Math.max(...produtos.map((p) => p.preco)) / 5
) * 5;

export default function Produtos() {
  const { categoria, subcategoria } = useParams();
  const [searchParams] = useSearchParams();
  const busca = searchParams.get("busca")?.trim().toLowerCase() || "";

  const [especie, setEspecie] = useState("");
  const [precoMax, setPrecoMax] = useState(PRECO_MAXIMO_CATALOGO);
  const [ordenacao, setOrdenacao] = useState("relevancia");

  const baseFiltrada = useMemo(() => {
    return produtos.filter((p) => {
      if (busca) {
        return p.nome.toLowerCase().includes(busca);
      }
      if (subcategoria) {
        return p.categoria === categoria && p.subcategoria === subcategoria;
      }
      if (categoria) {
        return p.categoria === categoria;
      }
      return true;
    });
  }, [busca, categoria, subcategoria]);

  const produtosFiltrados = useMemo(() => {
    let lista = baseFiltrada.filter((p) => p.preco <= precoMax);

    if (especie) {
      lista = lista.filter((p) => p.especie === especie);
    }

    const comMedia = lista.map((p) => {
      const avaliacoes = listarAvaliacoes(p.id);
      return { produto: p, media: calcularMedia(avaliacoes) };
    });

    switch (ordenacao) {
      case "menor-preco":
        comMedia.sort((a, b) => a.produto.preco - b.produto.preco);
        break;
      case "maior-preco":
        comMedia.sort((a, b) => b.produto.preco - a.produto.preco);
        break;
      case "melhor-avaliados":
        comMedia.sort((a, b) => b.media - a.media);
        break;
      case "nome":
        comMedia.sort((a, b) => a.produto.nome.localeCompare(b.produto.nome));
        break;
      default:
        break;
    }

    return comMedia.map((item) => item.produto);
  }, [baseFiltrada, especie, precoMax, ordenacao]);

  const titulo = busca
    ? `Resultados para "${searchParams.get("busca")}"`
    : subcategoria
    ? subcategoria.charAt(0).toUpperCase() + subcategoria.slice(1)
    : categoria
    ? categoria.charAt(0).toUpperCase() + categoria.slice(1)
    : "Todos os Produtos";

  return (
    <div className="p-6 sm:p-10">
      <h1 className="text-4xl font-bold capitalize mb-2">{titulo}</h1>
      <p className="text-gray-500 mb-8">
        {produtosFiltrados.length} produto{produtosFiltrados.length !== 1 ? "s" : ""} encontrado{produtosFiltrados.length !== 1 ? "s" : ""}
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr] gap-8">
        <aside className="lg:sticky lg:top-6 lg:self-start">
          <FiltrosProdutos
            especie={especie}
            setEspecie={setEspecie}
            precoMax={precoMax}
            setPrecoMax={setPrecoMax}
            ordenacao={ordenacao}
            setOrdenacao={setOrdenacao}
            precoMaximoDisponivel={PRECO_MAXIMO_CATALOGO}
          />
        </aside>

        <div>
          {produtosFiltrados.length === 0 ? (
            <div className="text-center py-20 text-gray-400">
              <p className="text-2xl">Nenhum produto encontrado.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {produtosFiltrados.map((produto) => (
                <ProdutoCard key={produto.id} produto={produto} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
