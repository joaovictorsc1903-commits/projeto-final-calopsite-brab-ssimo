export default function AveDeRapina() {
  return (
    <main className="bg-[#F7F3EE] min-h-screen py-12 px-4">

      {/* Aviso legal */}
      <section className="max-w-[960px] mx-auto mb-6">
        <div className="bg-[#FEF3E2] border border-[#F5C97A] rounded-2xl px-5 py-4 flex gap-3">
          <span className="text-lg mt-0.5">⚠️</span>
          <p className="text-sm text-[#7A4F00] leading-relaxed">
            <strong>Atenção:</strong> a posse, criação e prática da falcoaria com aves de rapina
            nativas no Brasil são atividades reguladas pelo IBAMA e exigem registro e autorização
            específicos (CTF/RAS). Adquira aves apenas de criadouros legalizados e nunca de origem
            silvestre não autorizada. Consulte sempre a legislação vigente antes de iniciar a atividade.
          </p>
        </div>
      </section>

      {/* Hero */}
      <section className="max-w-[960px] mx-auto mb-8">
        <div className="grid md:grid-cols-2 rounded-2xl overflow-hidden border border-[#E0D5C8]">

          <div className="relative bg-[#2C3E2E] min-h-[300px] flex items-center justify-center">
            <span className="text-7xl">🦅</span>
          </div>

          <div className="bg-white p-8 flex flex-col justify-center">
            <p className="text-[11px] font-medium tracking-[0.1em] uppercase text-[#9C7A52] mb-2">
              Falcoaria
            </p>
            <h1 className="text-4xl font-semibold text-[#2C2016] mb-4 leading-tight">
              Aves de Rapina
            </h1>
            <p className="text-sm text-gray-500 leading-relaxed">
              Falcões, gaviões e harris hawks são aves de rapina criadas em cativeiro para a
              prática da falcoaria — uma atividade milenar que envolve treinamento, manejo
              especializado e uma dieta baseada em presas naturais inteiras.
            </p>
          </div>

        </div>
      </section>

      {/* Stats */}
      <section className="max-w-[960px] mx-auto mb-8">
        <div className="grid grid-cols-3 divide-x divide-[#E0D5C8] border border-[#E0D5C8] rounded-2xl overflow-hidden bg-white">

          {[
            { value: "15–25 anos", label: "Expectativa de vida em cativeiro" },
            { value: "400g–1,5kg", label: "Peso adulto (varia por espécie)" },
            { value: "CTF/RAS", label: "Registro exigido pelo IBAMA" },
          ].map(({ value, label }) => (
            <div key={label} className="px-6 py-5">
              <p className="text-2xl font-semibold text-[#2C2016] mb-0.5">{value}</p>
              <p className="text-xs text-gray-400 leading-snug">{label}</p>
            </div>
          ))}

        </div>
      </section>

      {/* cards */}
      <section className="max-w-[960px] mx-auto grid md:grid-cols-2 gap-4">

        {/* Origem */}
        <div className="bg-white rounded-2xl border border-[#E0D5C8] p-6">
          <Tag>Sobre a falcoaria</Tag>
          <h2 className="text-base font-semibold text-[#2C2016] mb-2">Uma prática milenar</h2>
          <p className="text-sm text-gray-500 leading-relaxed">
            A falcoaria é a arte de treinar aves de rapina para a caça em parceria com o
            ser humano, praticada há mais de 4 mil anos. No Brasil, é regulamentada e exige
            que o falcoeiro obtenha registro junto ao IBAMA antes de adquirir ou manejar
            qualquer ave de rapina.
          </p>
        </div>

        {/* Comportamento */}
        <div className="bg-white rounded-2xl border border-[#E0D5C8] p-6">
          <Tag>Comportamento</Tag>
          <h2 className="text-base font-semibold text-[#2C2016] mb-2">Instinto de predação</h2>
          <p className="text-sm text-gray-500 leading-relaxed">
            Aves de rapina mantêm fortes instintos predatórios mesmo em cativeiro. O vínculo
            com o falcoeiro é construído através do manejo alimentar (técnica chamada
            "manning"), exigindo paciência, consistência e conhecimento técnico aprofundado.
          </p>
        </div>

        {/* Alimentação */}
        <div className="bg-white rounded-2xl border border-[#E0D5C8] p-6 md:col-span-2">
          <Tag>Alimentação</Tag>
          <h2 className="text-base font-semibold text-[#2C2016] mb-2">Dieta natural à base de presas</h2>
          <p className="text-sm text-gray-500 leading-relaxed mb-4">
            A dieta ideal reproduz o que a ave consumiria na natureza: presas inteiras como
            codornas, camundongos, ratos e pintinhos de um dia, oferecidas congeladas e
            descongeladas corretamente antes do consumo. Presas inteiras fornecem ossos, pele
            e penas/pelos essenciais para a saúde digestiva e o desgaste natural do bico.
          </p>
          <div className="bg-[#FEF3E2] border border-[#F5C97A] rounded-xl px-4 py-3 flex gap-3">
            <span className="text-base mt-0.5">⚠️</span>
            <p className="text-xs text-[#7A4F00] leading-relaxed">
              <strong>Cuidado no manejo:</strong> nunca ofereça carne moída ou processada como
              dieta exclusiva — a falta de ossos e fibras causa deficiências graves a médio prazo.
              Mantenha a cadeia de frio das presas congeladas e descongele apenas a quantidade
              do dia.
            </p>
          </div>
        </div>

        {/* Equipamentos */}
        <div className="bg-white rounded-2xl border border-[#E0D5C8] p-6 md:col-span-2">
          <Tag>Equipamentos</Tag>
          <h2 className="text-base font-semibold text-[#2C2016] mb-2">Itens essenciais do falcoeiro</h2>
          <p className="text-sm text-gray-500 leading-relaxed">
            A luva de couro protege o braço do falcoeiro durante o manejo. Grilhões (jess),
            pio (giz/swivel) e guizo permitem fixar e localizar a ave durante o treinamento e
            voos de caça. Todo equipamento deve ser revisado regularmente para evitar
            ferimentos ou fuga acidental da ave.
          </p>
        </div>

        {/* Cuidados */}
        <div className="bg-white rounded-2xl border border-[#E0D5C8] p-6 md:col-span-2">
          <Tag>Cuidados essenciais</Tag>
          <h2 className="text-base font-semibold text-[#2C2016] mb-4">Rotina de manejo responsável</h2>
          <ul className="flex flex-col gap-3">
            {[
              "Mantenha o registro junto ao IBAMA sempre atualizado e visite um médico-veterinário especializado em aves de rapina regularmente.",
              "Ofereça presas inteiras variadas, armazenadas congeladas e descongeladas em refrigerador — nunca em temperatura ambiente.",
              "Pese a ave diariamente antes do treinamento; o peso é o principal indicador de saúde e motivação para o voo.",
              "Garanta abrigo (mew) amplo, protegido de intempéries, com poleiros adequados ao porte da espécie.",
              "Nunca solte ou negligencie equipamentos de contenção — fugas colocam a ave e a fauna local em risco.",
            ].map((item, i) => (
              <li key={i} className="flex items-start gap-3 text-sm text-gray-500 leading-relaxed">
                <span className="w-5 h-5 rounded-full bg-[#F5EDE0] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <svg className="w-3 h-3 text-[#9C7A52]" fill="none" viewBox="0 0 12 12" stroke="currentColor" strokeWidth={2.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M2 6l3 3 5-5" />
                  </svg>
                </span>
                {item}
              </li>
            ))}
          </ul>
        </div>

      </section>

      <p className="max-w-[960px] mx-auto mt-6 text-center text-xs text-gray-400">
        As informações acima têm caráter educativo. A posse e o manejo de aves de rapina exigem
        registro junto ao IBAMA. Consulte sempre a legislação vigente e um médico-veterinário
        especializado antes de iniciar a atividade.
      </p>

    </main>
  );
}

function Tag({ children }) {
  return (
    <span className="inline-flex items-center gap-1.5 text-[11px] font-medium tracking-wider uppercase text-[#7A5C34] bg-[#F5EDE0] px-2.5 py-1 rounded mb-3">
      {children}
    </span>
  );
}
