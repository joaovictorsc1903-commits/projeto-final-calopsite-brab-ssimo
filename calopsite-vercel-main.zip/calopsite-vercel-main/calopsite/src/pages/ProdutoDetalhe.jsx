import { useContext, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { FaCheck, FaShoppingCart, FaArrowLeft, FaPaperPlane } from "react-icons/fa";
import produtos from "../data/Produtos";
import { CartContext } from "../context/CartContext";
import BotaoFavorito from "../components/BotaoFavorito";
import EstrelasAvaliacao from "../components/EstrelasAvaliacao";
import ProdutoCard from "../components/ProdutoCard";
import {
  listarAvaliacoes,
  adicionarAvaliacao,
  calcularMedia,
} from "../utils/avaliacoes";

function formatarData(iso) {
  return new Date(iso).toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export default function ProdutoDetalhe() {
  const { id } = useParams();
  const navigate = useNavigate();
  const cart = useContext(CartContext);

  const produto = produtos.find((p) => String(p.id) === String(id));

  const [quantidade, setQuantidade] = useState(1);
  const [adicionado, setAdicionado] = useState(false);
  const [avaliacoes, setAvaliacoes] = useState(() =>
    produto ? listarAvaliacoes(produto.id) : []
  );
  const [novaNota, setNovaNota] = useState(5);
  const [novoComentario, setNovoComentario] = useState("");
  const [novoAutor, setNovoAutor] = useState("");
  const [enviado, setEnviado] = useState(false);

  if (!produto) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-16 text-center">
        <h1 className="text-2xl font-bold text-gray-800 mb-2">
          Produto não encontrado
        </h1>
        <p className="text-gray-500 mb-6">
          O produto que você procura não existe ou foi removido.
        </p>
        <Link
          to="/produtos"
          className="inline-flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-medium px-6 py-3 rounded-full transition"
        >
          <FaArrowLeft size={14} /> Ver produtos
        </Link>
      </div>
    );
  }

  const media = calcularMedia(avaliacoes);

  const relacionados = produtos
    .filter(
      (p) =>
        p.id !== produto.id &&
        (p.especie === produto.especie || p.categoria === produto.categoria)
    )
    .slice(0, 4);

  const handleComprar = () => {
    cart?.adicionarItem(produto, quantidade);
    setAdicionado(true);
    setTimeout(() => setAdicionado(false), 1500);
  };

  const handleEnviarAvaliacao = (e) => {
    e.preventDefault();
    if (!novoComentario.trim()) return;

    const nova = adicionarAvaliacao(produto.id, {
      autor: novoAutor,
      nota: novaNota,
      comentario: novoComentario,
    });

    setAvaliacoes((prev) => [nova, ...prev]);
    setNovoComentario("");
    setNovoAutor("");
    setNovaNota(5);
    setEnviado(true);
    setTimeout(() => setEnviado(false), 2500);
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <button
        type="button"
        onClick={() => navigate(-1)}
        className="inline-flex items-center gap-2 text-orange-600 hover:text-orange-700 font-medium mb-6 text-sm"
      >
        <FaArrowLeft size={12} /> Voltar
      </button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-14">
        {/* GALERIA */}
        <div className="relative bg-gray-100 rounded-2xl overflow-hidden h-[420px]">
          <img
            src={produto.imagem}
            alt={produto.nome}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.target.src = "https://placehold.co/500x500?text=Produto";
            }}
          />
          <BotaoFavorito
            produtoId={produto.id}
            tamanho={18}
            className="absolute top-4 right-4 w-11 h-11 bg-white shadow-md"
          />
        </div>

        {/* INFO */}
        <div className="flex flex-col">
          <span className="text-xs uppercase tracking-wide text-orange-500 font-semibold mb-2">
            {produto.categoria} · {produto.subcategoria}
          </span>
          <h1 className="text-3xl font-bold text-gray-800 mb-3">{produto.nome}</h1>

          {avaliacoes.length > 0 && (
            <div className="flex items-center gap-2 mb-4">
              <EstrelasAvaliacao nota={media} tamanho={16} />
              <span className="text-sm text-gray-500">
                {media.toFixed(1)} · {avaliacoes.length} avaliaç{avaliacoes.length === 1 ? "ão" : "ões"}
              </span>
            </div>
          )}

          <p className="text-gray-600 leading-relaxed mb-6">{produto.descricao}</p>

          <p className="text-3xl font-bold text-orange-600 mb-6">
            R$ {produto.preco.toFixed(2).replace(".", ",")}
          </p>

          <div className="flex items-center gap-4 mb-6">
            <div className="flex items-center gap-2 border border-gray-200 rounded-full px-2 py-1">
              <button
                type="button"
                onClick={() => setQuantidade((q) => Math.max(1, q - 1))}
                className="w-9 h-9 flex items-center justify-center rounded-full text-gray-600 hover:bg-gray-100 transition"
              >
                −
              </button>
              <span className="w-8 text-center font-medium">{quantidade}</span>
              <button
                type="button"
                onClick={() => setQuantidade((q) => q + 1)}
                className="w-9 h-9 flex items-center justify-center rounded-full text-gray-600 hover:bg-gray-100 transition"
              >
                +
              </button>
            </div>

            <button
              type="button"
              onClick={handleComprar}
              className={`flex-1 flex items-center justify-center gap-2 font-semibold px-6 py-3 rounded-full transition ${
                adicionado
                  ? "bg-green-600 text-white"
                  : "bg-orange-500 hover:bg-orange-600 text-white"
              }`}
            >
              {adicionado ? (
                <>
                  <FaCheck /> Adicionado ao carrinho
                </>
              ) : (
                <>
                  <FaShoppingCart /> Adicionar ao carrinho
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* AVALIAÇÕES */}
      <section className="mb-14">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">
          Avaliações ({avaliacoes.length})
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* LISTA */}
          <div className="lg:col-span-2 flex flex-col gap-4">
            {avaliacoes.length === 0 ? (
              <p className="text-gray-400">Seja o primeiro a avaliar este produto.</p>
            ) : (
              avaliacoes.map((a) => (
                <div
                  key={a.id}
                  className="border border-gray-200 rounded-xl p-4 bg-white shadow-sm"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-gray-800 text-sm">{a.autor}</span>
                    <span className="text-xs text-gray-400">{formatarData(a.data)}</span>
                  </div>
                  <EstrelasAvaliacao nota={a.nota} tamanho={12} />
                  <p className="text-sm text-gray-600 mt-2 leading-relaxed">{a.comentario}</p>
                </div>
              ))
            )}
          </div>

          {/* FORMULÁRIO */}
          <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm h-fit">
            <h3 className="font-bold text-gray-800 mb-4">Deixe sua avaliação</h3>
            <form onSubmit={handleEnviarAvaliacao} className="flex flex-col gap-4">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-2">
                  Sua nota
                </label>
                <EstrelasAvaliacao
                  nota={novaNota}
                  interativo
                  onChange={setNovaNota}
                  tamanho={14}
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">
                  Seu nome (opcional)
                </label>
                <input
                  type="text"
                  value={novoAutor}
                  onChange={(e) => setNovoAutor(e.target.value)}
                  placeholder="Como quer aparecer"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">
                  Comentário
                </label>
                <textarea
                  value={novoComentario}
                  onChange={(e) => setNovoComentario(e.target.value)}
                  placeholder="Conte como foi sua experiência..."
                  rows={3}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={!novoComentario.trim()}
                className="flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium py-2.5 rounded-full transition text-sm"
              >
                <FaPaperPlane size={12} /> Enviar avaliação
              </button>

              {enviado && (
                <p className="text-xs text-green-600 text-center">
                  Avaliação enviada com sucesso!
                </p>
              )}
            </form>
          </div>
        </div>
      </section>

      {/* RELACIONADOS */}
      {relacionados.length > 0 && (
        <section>
          <h2 className="text-2xl font-bold text-gray-800 mb-6">
            Você também pode gostar
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {relacionados.map((p) => (
              <ProdutoCard key={p.id} produto={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
