import { useContext } from "react";
import { Link } from "react-router-dom";
import { FaBoxOpen, FaArrowLeft, FaChevronRight } from "react-icons/fa";
import { AuthContext } from "../context/AuthContext";
import { listarPedidosDoUsuario } from "../utils/pedidos";

const LABEL_PAGAMENTO = {
  pix: "Pix",
  cartao: "Cartão de Crédito",
  boleto: "Boleto",
};

const COR_STATUS = {
  "Pedido confirmado": "bg-blue-100 text-blue-700",
  "Em preparação": "bg-yellow-100 text-yellow-700",
  Enviado: "bg-purple-100 text-purple-700",
  "Em rota de entrega": "bg-orange-100 text-orange-700",
  Entregue: "bg-green-100 text-green-700",
};

export default function MeusPedidos() {
  const auth = useContext(AuthContext);
  const pedidos = listarPedidosDoUsuario(auth?.user?.email);

  const formatarPreco = (valor) => `R$ ${valor.toFixed(2).replace(".", ",")}`;
  const formatarData = (iso) =>
    new Date(iso).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });

  if (pedidos.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-16 text-center">
        <FaBoxOpen className="mx-auto text-gray-300 mb-4" size={56} />
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          Você ainda não fez nenhum pedido
        </h1>
        <p className="text-gray-500 mb-8">
          {auth?.user
            ? "Quando você comprar algo, seus pedidos aparecerão aqui."
            : "Faça login para ver seu histórico, ou continue como visitante e seus pedidos ficarão salvos neste navegador."}
        </p>
        <Link
          to="/produtos"
          className="inline-flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-medium px-6 py-3 rounded-full transition"
        >
          <FaArrowLeft size={14} /> Ver produtos
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-6 py-10">
      <h1 className="text-3xl font-bold text-gray-800 mb-1">Meus Pedidos</h1>
      <p className="text-gray-500 mb-8">
        {pedidos.length} pedido{pedidos.length !== 1 ? "s" : ""}
        {auth?.user ? ` · ${auth.user.email}` : " · modo visitante"}
      </p>

      <div className="flex flex-col gap-4">
        {pedidos.map((pedido) => (
          <Link
            key={pedido.numero}
            to={`/pedido/${pedido.numero}/rastreio`}
            className="block bg-white border border-gray-200 rounded-xl p-5 shadow-sm hover:shadow-md hover:border-orange-200 transition"
          >
            <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
              <div>
                <p className="text-xs text-gray-400 uppercase tracking-wide">Pedido</p>
                <p className="font-bold text-gray-800">{pedido.numero}</p>
              </div>
              <span
                className={`text-xs font-medium px-3 py-1 rounded-full ${
                  COR_STATUS[pedido.statusAtual] || "bg-gray-100 text-gray-600"
                }`}
              >
                {pedido.statusAtual}
              </span>
            </div>

            <div className="flex items-center gap-3 mb-3 overflow-x-auto">
              {pedido.itens?.slice(0, 4).map((item) => (
                <img
                  key={item.id}
                  src={item.imagem}
                  alt={item.nome}
                  className="w-12 h-12 object-cover rounded-lg bg-gray-100 flex-shrink-0"
                  onError={(e) => {
                    e.target.src = "https://placehold.co/48x48?text=Produto";
                  }}
                />
              ))}
              {pedido.itens?.length > 4 && (
                <span className="text-xs text-gray-400 flex-shrink-0">
                  +{pedido.itens.length - 4}
                </span>
              )}
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">
                {formatarData(pedido.data)} · {LABEL_PAGAMENTO[pedido.pagamento] || pedido.pagamento}
              </span>
              <div className="flex items-center gap-2">
                <span className="font-bold text-orange-600">{formatarPreco(pedido.total)}</span>
                <FaChevronRight className="text-gray-300" size={12} />
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
