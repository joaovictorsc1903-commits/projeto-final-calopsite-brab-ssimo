import { Link, useParams } from "react-router-dom";
import { FaCheck, FaArrowLeft, FaMapMarkerAlt } from "react-icons/fa";
import { buscarPedidoPorNumero, STATUS_FLOW } from "../utils/pedidos";

export default function RastreioPedido() {
  const { numero } = useParams();
  const pedido = buscarPedidoPorNumero(numero);

  if (!pedido) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-16 text-center">
        <h1 className="text-2xl font-bold text-gray-800 mb-2">
          Pedido não encontrado
        </h1>
        <p className="text-gray-500 mb-6">
          Verifique o número do pedido ou confira seu histórico de compras.
        </p>
        <Link
          to="/meus-pedidos"
          className="inline-flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-medium px-6 py-3 rounded-full transition"
        >
          <FaArrowLeft size={14} /> Ver meus pedidos
        </Link>
      </div>
    );
  }

  const indiceAtual = STATUS_FLOW.indexOf(pedido.statusAtual);
  const formatarData = (iso) =>
    new Date(iso).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    });

  const previsaoEntrega = new Date(pedido.data);
  previsaoEntrega.setDate(previsaoEntrega.getDate() + 7);

  return (
    <div className="max-w-3xl mx-auto px-6 py-10">
      <Link
        to="/meus-pedidos"
        className="inline-flex items-center gap-2 text-orange-600 hover:text-orange-700 font-medium mb-6 text-sm"
      >
        <FaArrowLeft size={12} /> Voltar aos meus pedidos
      </Link>

      <div className="flex flex-wrap items-center justify-between gap-3 mb-8">
        <div>
          <p className="text-xs text-gray-400 uppercase tracking-wide">Pedido</p>
          <h1 className="text-2xl font-bold text-gray-800">{pedido.numero}</h1>
        </div>
        <p className="text-sm text-gray-500">
          Realizado em {formatarData(pedido.data)}
        </p>
      </div>

      {/* LINHA DO TEMPO */}
      <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm mb-6">
        <h2 className="font-bold text-gray-800 mb-6">Status da entrega</h2>

        <div className="flex flex-col">
          {STATUS_FLOW.map((status, i) => {
            const concluido = i <= indiceAtual;
            const ehUltimo = i === STATUS_FLOW.length - 1;

            return (
              <div key={status} className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      concluido
                        ? "bg-orange-500 text-white"
                        : "bg-gray-100 text-gray-400"
                    }`}
                  >
                    {concluido ? <FaCheck size={12} /> : <span className="text-xs">{i + 1}</span>}
                  </div>
                  {!ehUltimo && (
                    <div
                      className={`w-0.5 flex-1 min-h-[28px] ${
                        i < indiceAtual ? "bg-orange-500" : "bg-gray-200"
                      }`}
                    />
                  )}
                </div>
                <div className={`pb-7 ${ehUltimo ? "pb-0" : ""}`}>
                  <p
                    className={`font-medium ${
                      concluido ? "text-gray-800" : "text-gray-400"
                    }`}
                  >
                    {status}
                  </p>
                  {i === indiceAtual && (
                    <p className="text-xs text-orange-600 mt-0.5">Status atual</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ENDEREÇO */}
      <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm mb-6 flex items-start gap-3">
        <FaMapMarkerAlt className="text-orange-500 mt-1 flex-shrink-0" />
        <div>
          <p className="font-medium text-gray-800 mb-1">Endereço de entrega</p>
          <p className="text-sm text-gray-500">
            {pedido.endereco?.logradouro}, {pedido.endereco?.numero}
            {pedido.endereco?.complemento ? ` - ${pedido.endereco.complemento}` : ""} ·{" "}
            {pedido.endereco?.bairro}, {pedido.endereco?.localidade}/{pedido.endereco?.uf} ·{" "}
            CEP {pedido.endereco?.cep}
          </p>
          {pedido.statusAtual !== "Entregue" && (
            <p className="text-sm text-gray-400 mt-2">
              Previsão de entrega: {formatarData(previsaoEntrega.toISOString())}
            </p>
          )}
        </div>
      </div>

      {/* ITENS */}
      <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
        <h2 className="font-bold text-gray-800 mb-4">Itens do pedido</h2>
        <div className="flex flex-col gap-3">
          {pedido.itens?.map((item) => (
            <div key={item.id} className="flex items-center gap-3">
              <img
                src={item.imagem}
                alt={item.nome}
                className="w-12 h-12 object-cover rounded-lg bg-gray-100 flex-shrink-0"
                onError={(e) => {
                  e.target.src = "https://placehold.co/48x48?text=Produto";
                }}
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-700 truncate">{item.nome}</p>
                <p className="text-xs text-gray-400">Qtd: {item.quantidade}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
