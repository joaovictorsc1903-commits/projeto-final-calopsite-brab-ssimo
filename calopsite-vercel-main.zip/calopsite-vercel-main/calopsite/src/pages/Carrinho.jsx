import { useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FaMinus, FaPlus, FaTrash, FaShoppingBag, FaArrowLeft } from "react-icons/fa";
import { CartContext } from "../context/CartContext";

export default function Carrinho() {
  const cart = useContext(CartContext);
  const navigate = useNavigate();

  const itens = cart?.itens || [];
  const totalPreco = cart?.totalPreco || 0;
  const totalItens = cart?.totalItens || 0;

  const formatarPreco = (valor) =>
    `R$ ${valor.toFixed(2).replace(".", ",")}`;

  if (itens.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-16 text-center">
        <FaShoppingBag className="mx-auto text-gray-300 mb-4" size={64} />
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          Seu carrinho está vazio
        </h1>
        <p className="text-gray-500 mb-8">
          Que tal dar uma olhada nos nossos produtos para sua ave?
        </p>
        <Link
          to="/produtos"
          className="inline-flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-medium px-6 py-3 rounded-full transition"
        >
          <FaArrowLeft size={14} /> Ver produtos
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-6 py-10">
      <h1 className="text-3xl font-bold text-gray-800 mb-1">Meu Carrinho</h1>
      <p className="text-gray-500 mb-8">
        {totalItens} ite{totalItens === 1 ? "m" : "ns"} no carrinho
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* LISTA DE ITENS */}
        <div className="lg:col-span-2 flex flex-col gap-4">
          {itens.map((item) => (
            <div
              key={item.id}
              className="flex items-center gap-4 bg-white border border-gray-200 rounded-xl p-4 shadow-sm"
            >
              <img
                src={item.imagem}
                alt={item.nome}
                className="w-20 h-20 object-cover rounded-lg bg-gray-100 flex-shrink-0"
                onError={(e) => {
                  e.target.src = "https://placehold.co/80x80?text=Produto";
                }}
              />

              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-gray-800 text-sm leading-snug line-clamp-2">
                  {item.nome}
                </h3>
                <p className="text-orange-600 font-bold mt-1">
                  {formatarPreco(item.preco)}
                </p>
              </div>

              {/* QUANTIDADE */}
              <div className="flex items-center gap-2 border border-gray-200 rounded-full px-2 py-1">
                <button
                  type="button"
                  onClick={() =>
                    cart?.alterarQuantidade(item.id, item.quantidade - 1)
                  }
                  disabled={item.quantidade <= 1}
                  className="w-7 h-7 flex items-center justify-center rounded-full text-gray-600 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition"
                  aria-label="Diminuir quantidade"
                >
                  <FaMinus size={10} />
                </button>
                <span className="w-6 text-center text-sm font-medium">
                  {item.quantidade}
                </span>
                <button
                  type="button"
                  onClick={() =>
                    cart?.alterarQuantidade(item.id, item.quantidade + 1)
                  }
                  className="w-7 h-7 flex items-center justify-center rounded-full text-gray-600 hover:bg-gray-100 transition"
                  aria-label="Aumentar quantidade"
                >
                  <FaPlus size={10} />
                </button>
              </div>

              {/* SUBTOTAL DO ITEM */}
              <div className="hidden sm:block text-right w-24 font-semibold text-gray-800">
                {formatarPreco(item.preco * item.quantidade)}
              </div>

              <button
                type="button"
                onClick={() => cart?.removerItem(item.id)}
                className="text-gray-400 hover:text-red-500 transition p-2"
                aria-label="Remover item"
                title="Remover item"
              >
                <FaTrash size={15} />
              </button>
            </div>
          ))}

          <Link
            to="/produtos"
            className="inline-flex items-center gap-2 text-orange-600 hover:text-orange-700 font-medium mt-2 text-sm"
          >
            <FaArrowLeft size={12} /> Continuar comprando
          </Link>
        </div>

        {/* RESUMO */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm h-fit sticky top-6">
          <h2 className="text-lg font-bold text-gray-800 mb-4">
            Resumo do pedido
          </h2>

          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Subtotal ({totalItens} {totalItens === 1 ? "item" : "itens"})</span>
            <span>{formatarPreco(totalPreco)}</span>
          </div>
          <div className="flex justify-between text-sm text-gray-600 mb-4">
            <span>Frete</span>
            <span className="text-green-600 font-medium">Calculado no checkout</span>
          </div>

          <div className="border-t border-gray-200 pt-4 mb-6 flex justify-between items-baseline">
            <span className="font-semibold text-gray-800">Total</span>
            <span className="text-2xl font-bold text-orange-600">
              {formatarPreco(totalPreco)}
            </span>
          </div>

          <button
            type="button"
            onClick={() => navigate("/checkout")}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white font-semibold py-3 rounded-full transition"
          >
            Finalizar Compra
          </button>
        </div>
      </div>
    </div>
  );
}
