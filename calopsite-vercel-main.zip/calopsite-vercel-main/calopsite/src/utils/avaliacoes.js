// Sistema de avaliações de produtos.
// Avaliações "seed" são geradas de forma determinística a partir do id do produto
// (mesmas sempre, para não precisar cadastrar uma a uma em 50 produtos).
// Avaliações novas, feitas pelo usuário, ficam salvas em localStorage.

const STORAGE_KEY = "calopsite_avaliacoes";

const NOMES = [
  "Marina S.", "Carlos E.", "Beatriz A.", "João P.", "Fernanda L.",
  "Ricardo M.", "Patrícia G.", "Lucas T.", "Camila R.", "André F.",
  "Juliana C.", "Pedro H.", "Larissa V.", "Gustavo N.", "Tatiane B.",
];

const COMENTARIOS_POSITIVOS = [
  "Minha ave adorou, recomendo muito!",
  "Produto de ótima qualidade, chegou bem embalado.",
  "Já é a segunda vez que compro, sempre satisfeita.",
  "Superou minhas expectativas, vou comprar novamente.",
  "Entrega rápida e produto exatamente como anunciado.",
  "Notei diferença na disposição da minha ave em poucos dias.",
];

const COMENTARIOS_NEUTROS = [
  "Bom produto, mas achei o preço um pouco alto.",
  "Atendeu o esperado, nada excepcional.",
  "Cumpre a função, embalagem poderia ser melhor.",
  "Gostei, mas a entrega demorou um pouco mais que o previsto.",
];

function hashSimples(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

function gerarSeedParaProduto(produtoId) {
  const seedBase = hashSimples(`produto-${produtoId}`);
  const quantidade = 2 + (seedBase % 3); // 2 a 4 avaliações seed
  const avaliacoes = [];

  for (let i = 0; i < quantidade; i++) {
    const seed = hashSimples(`produto-${produtoId}-avaliacao-${i}`);
    const nota = 4 + (seed % 2); // notas 4 ou 5 predominam (loja bem avaliada)
    const usarPositivo = seed % 5 !== 0; // 80% comentário positivo
    const banco = usarPositivo ? COMENTARIOS_POSITIVOS : COMENTARIOS_NEUTROS;
    const comentario = banco[seed % banco.length];
    const autor = NOMES[seed % NOMES.length];
    const diasAtras = 5 + (seed % 120);
    const data = new Date(Date.now() - diasAtras * 86400000).toISOString();

    avaliacoes.push({
      id: `seed-${produtoId}-${i}`,
      autor,
      nota,
      comentario,
      data,
      seed: true,
    });
  }

  return avaliacoes;
}

function lerAvaliacoesUsuario() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

function salvarAvaliacoesUsuario(todas) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(todas));
  } catch {
    // localStorage indisponível — ignora silenciosamente
  }
}

export function listarAvaliacoes(produtoId) {
  const seed = gerarSeedParaProduto(produtoId);
  const todasDoUsuario = lerAvaliacoesUsuario();
  const doUsuario = Array.isArray(todasDoUsuario[produtoId]) ? todasDoUsuario[produtoId] : [];

  return [...doUsuario, ...seed].sort((a, b) => new Date(b.data) - new Date(a.data));
}

export function adicionarAvaliacao(produtoId, { autor, nota, comentario }) {
  const todas = lerAvaliacoesUsuario();
  const listaAtual = Array.isArray(todas[produtoId]) ? todas[produtoId] : [];

  const novaAvaliacao = {
    id: `user-${Date.now()}`,
    autor: autor?.trim() || "Anônimo",
    nota: Math.min(5, Math.max(1, Number(nota) || 5)),
    comentario: comentario?.trim() || "",
    data: new Date().toISOString(),
    seed: false,
  };

  todas[produtoId] = [novaAvaliacao, ...listaAtual];
  salvarAvaliacoesUsuario(todas);

  return novaAvaliacao;
}

export function calcularMedia(avaliacoes) {
  if (!avaliacoes || avaliacoes.length === 0) return 0;
  const soma = avaliacoes.reduce((acc, a) => acc + a.nota, 0);
  return soma / avaliacoes.length;
}
