// Gerencia o histórico de pedidos, persistido em localStorage.
// Pedidos são associados ao e-mail do usuário logado, ou "guest" se não logado.

const STORAGE_KEY = "calopsite_pedidos";
const ULTIMO_PEDIDO_KEY = "calopsite_ultimo_pedido";

const STATUS_FLOW = [
  "Pedido confirmado",
  "Em preparação",
  "Enviado",
  "Em rota de entrega",
  "Entregue",
];

function lerTodosPedidos() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function salvarTodosPedidos(pedidos) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(pedidos));
  } catch {
    // ignora falha de storage
  }
}

function calcularStatusAtual(pedido) {
  const horasDesdeCompra = (Date.now() - new Date(pedido.data).getTime()) / 3600000;
  // Avança um status a cada 20h corridas, de forma simulada
  const indice = Math.min(
    STATUS_FLOW.length - 1,
    Math.floor(horasDesdeCompra / 20)
  );
  return STATUS_FLOW[indice];
}

export function salvarPedido(pedido, usuarioEmail) {
  const pedidos = lerTodosPedidos();
  const pedidoCompleto = {
    ...pedido,
    usuario: usuarioEmail || "guest",
  };

  pedidos.unshift(pedidoCompleto);
  salvarTodosPedidos(pedidos);

  try {
    sessionStorage.setItem(ULTIMO_PEDIDO_KEY, JSON.stringify(pedidoCompleto));
  } catch {
    // ignora falha de storage
  }

  return pedidoCompleto;
}

export function listarPedidosDoUsuario(usuarioEmail) {
  const pedidos = lerTodosPedidos();
  const chave = usuarioEmail || "guest";
  return pedidos
    .filter((p) => p.usuario === chave)
    .map((p) => ({ ...p, statusAtual: calcularStatusAtual(p) }));
}

export function buscarPedidoPorNumero(numero) {
  const pedidos = lerTodosPedidos();
  const pedido = pedidos.find((p) => p.numero === numero);
  if (!pedido) return null;
  return { ...pedido, statusAtual: calcularStatusAtual(pedido) };
}

export function migrarPedidosGuestParaUsuario(usuarioEmail) {
  if (!usuarioEmail) return;
  const pedidos = lerTodosPedidos();
  let alterou = false;

  const atualizados = pedidos.map((p) => {
    if (p.usuario === "guest") {
      alterou = true;
      return { ...p, usuario: usuarioEmail };
    }
    return p;
  });

  if (alterou) {
    salvarTodosPedidos(atualizados);
  }
}

export function lerUltimoPedido() {
  try {
    const raw = sessionStorage.getItem(ULTIMO_PEDIDO_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export { STATUS_FLOW };
