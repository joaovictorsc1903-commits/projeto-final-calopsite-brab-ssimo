export function normalizeCep(value) {
  const digits = String(value || "").replace(/\D/g, "");
  if (digits.length !== 8) return "";
  return `${digits.slice(0, 5)}-${digits.slice(5)}`;
}

export async function fetchCepData(cep) {
  const normalized = normalizeCep(cep);
  if (!normalized) throw new Error("CEP inválido");

  // viaCEP (serviço público)
  const digits = normalized.replace(/\D/g, "");

  let res;
  try {
    res = await fetch(`https://viacep.com.br/ws/${digits}/json/`);
  } catch {
    throw new Error("Não foi possível buscar o CEP. Preencha o endereço manualmente.");
  }

  if (!res.ok) throw new Error("Falha ao consultar CEP. Preencha o endereço manualmente.");

  const data = await res.json();
  if (data.erro) throw new Error("CEP não encontrado. Verifique e tente novamente.");

  return {
    cep: normalized,
    logradouro: data.logradouro || "",
    complemento: data.complemento || "",
    bairro: data.bairro || "",
    localidade: data.localidade || "",
    uf: data.uf || "",
  };
}

