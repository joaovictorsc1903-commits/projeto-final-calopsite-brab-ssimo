import { createContext, useEffect, useState } from "react";

export const FavoritosContext = createContext(null);

const STORAGE_KEY = "calopsite_favoritos";

function loadFavoritos() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function FavoritosProvider({ children }) {
  const [favoritos, setFavoritos] = useState(() => loadFavoritos());

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(favoritos));
    } catch {
      // ignora falha de storage
    }
  }, [favoritos]);

  const isFavorito = (id) => favoritos.includes(id);

  const alternarFavorito = (id) => {
    setFavoritos((prev) => {
      const lista = Array.isArray(prev) ? prev : [];
      return lista.includes(id) ? lista.filter((f) => f !== id) : [...lista, id];
    });
  };

  return (
    <FavoritosContext.Provider value={{ favoritos, isFavorito, alternarFavorito }}>
      {children}
    </FavoritosContext.Provider>
  );
}
